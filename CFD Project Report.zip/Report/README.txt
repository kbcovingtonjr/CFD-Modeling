This is the file `README', which is part of the `aiaa' distribution.

Run 'latex aiaa.ins' to produce the files aiaa-tc.cls and aiaa.bst.

This distribution contains a LaTeX class (aiaa-tc.cls) and bibliography
style file (aiaa.bst) that are used to create AIAA technical conference
papers.  (Both can be obtained by processing aiaa.ins with with LaTeX.)

This distribution also contains a Users Manual (aiaa.pdf), AIAA paper
submission instructions (author_guide.pdf), and a template from which
to start your paper (template.tex).

For adventurous soles, there is also an example conference paper
that employs advanced, third-party LaTeX packages (advanced_example.tex).

For further details, such as installation instructions or how to get
support, please read the Users Manual (aiaa.pdf).

- Release $Name:  $ -
